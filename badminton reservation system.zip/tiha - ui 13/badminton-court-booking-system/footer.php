<style>
@media print {
    footer, hr {
        display: none !important;
    }
}
</style>

<hr>
<footer style="text-align: center; padding: 20px 0; background-color: #d3d3d3;">
  <p style="font-size: 20px; font-weight: bold; color: black;">&copy; 2025 Dewan Badminton PDTJ</p>
</footer>
